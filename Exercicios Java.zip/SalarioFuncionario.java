import java.util.Scanner;

public class SalarioFuncionario {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Nome do Funcionário: ");
        String nome = scanner.nextLine();

        System.out.print("Salário: ");
        double salario = scanner.nextDouble();

        System.out.println("O funcionário " + nome + " tem um salário de R$" + String.format("%.2f", salario) + " em junho.");

        scanner.close();
    }
}
