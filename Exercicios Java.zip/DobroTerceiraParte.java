import java.util.Scanner;

public class DobroTerceiraParte {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite um número: ");
        double numero = scanner.nextDouble();

        double dobro = numero * 2;
        double terceiraParte = numero / 3;

        System.out.println("O dobro de " + numero + " é " + String.format("%.1f", dobro));
        System.out.println("A terça parte de " + numero + " é " + String.format("%.5f", terceiraParte));

        scanner.close();
    }
}
