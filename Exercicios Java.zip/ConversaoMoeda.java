import java.util.Scanner;

public class ConversaoMoeda {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Quanto dinheiro você tem na carteira (em R$): ");
        double dinheiro = scanner.nextDouble();

        double cotacao = 3.45;
        double dolares = dinheiro / cotacao;

        System.out.println("Com R$" + dinheiro + " você pode comprar US$" + String.format("%.2f", dolares));

        scanner.close();
    }
}
