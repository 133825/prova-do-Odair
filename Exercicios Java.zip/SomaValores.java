import java.util.Scanner;

public class SomaValores {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite um valor: ");
        int num1 = scanner.nextInt();

        System.out.print("Digite outro valor: ");
        int num2 = scanner.nextInt();

        int soma = num1 + num2;

        System.out.println("A soma entre " + num1 + " e " + num2 + " é igual a " + soma + ".");

        scanner.close();
    }
}
