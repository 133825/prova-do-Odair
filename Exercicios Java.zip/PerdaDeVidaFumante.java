import java.util.Scanner;

public class PerdaDeVidaFumante {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar entrada do usuário
        System.out.print("Quantos cigarros você fuma por dia? ");
        int cigarrosPorDia = scanner.nextInt();

        System.out.print("Há quantos anos você fuma? ");
        int anosFumando = scanner.nextInt();

        // Definir constantes
        int minutosPerdidosPorCigarro = 10;
        int minutosPorDia = 24 * 60; // Total de minutos em um dia

        // Calcular total de cigarros fumados
        int totalCigarros = cigarrosPorDia * anosFumando * 365;

        // Calcular total de minutos perdidos
        int totalMinutosPerdidos = totalCigarros * minutosPerdidosPorCigarro;

        // Converter minutos perdidos para dias
        int diasPerdidos = totalMinutosPerdidos / minutosPorDia;

        // Exibir o resultado
        System.out.println("Você perdeu aproximadamente " + diasPerdidos + " dias de vida devido ao fumo.");

        scanner.close();
    }
}
