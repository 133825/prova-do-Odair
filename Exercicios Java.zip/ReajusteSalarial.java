import java.util.Scanner;

public class ReajusteSalarial {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Ler o salário do funcionário
        System.out.print("Digite o salário atual do funcionário (R$): ");
        double salario = scanner.nextDouble();

        // Calcular o aumento de 15%
        double aumento = salario * 0.15;
        double novoSalario = salario + aumento;

        // Exibir o novo salário
        System.out.println("O novo salário com 15% de aumento é: R$" + String.format("%.2f", novoSalario));

        scanner.close();
    }
}
