import java.util.Scanner;

public class CalculoSalario {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Ler o número de dias trabalhados
        System.out.print("Digite o número de dias trabalhados no mês: ");
        int diasTrabalhados = scanner.nextInt();

        // Definir valores fixos
        int horasPorDia = 8;
        double valorPorHora = 25.0;

        // Calcular o salário
        double salario = diasTrabalhados * horasPorDia * valorPorHora;

        // Exibir o salário final
        System.out.println("O salário do funcionário é: R$" + String.format("%.2f", salario));

        scanner.close();
    }
}
