import java.util.Scanner;

public class AluguelCarro {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Ler a quantidade de dias alugados
        System.out.print("Quantos dias o carro foi alugado? ");
        int dias = scanner.nextInt();

        // Ler a quantidade de quilômetros percorridos
        System.out.print("Quantos Km foram percorridos? ");
        double kmPercorridos = scanner.nextDouble();

        // Definir os preços por dia e por Km
        double precoPorDia = 90.00;
        double precoPorKm = 0.20;

        // Calcular o preço total
        double total = (dias * precoPorDia) + (kmPercorridos * precoPorKm);

        // Exibir o preço total a pagar
        System.out.println("O total a pagar pelo aluguel é: R$" + String.format("%.2f", total));

        scanner.close();
    }
}
