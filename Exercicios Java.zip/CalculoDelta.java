import java.util.Scanner;

public class CalculoDelta {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Leitura dos valores de A, B e C
        System.out.print("Digite o valor de A: ");
        double A = scanner.nextDouble();

        System.out.print("Digite o valor de B: ");
        double B = scanner.nextDouble();

        System.out.print("Digite o valor de C: ");
        double C = scanner.nextDouble();

        // Calculando o valor de Delta (Δ)
        double delta = (B * B) - (4 * A * C);

        // Exibindo o valor de Delta
        System.out.println("O valor de Delta (Δ) é: " + delta);

        scanner.close();
    }
}
