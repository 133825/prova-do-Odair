import java.util.Scanner;

public class PrecoPromocional {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Ler o preço do produto
        System.out.print("Digite o preço do produto (R$): ");
        double preco = scanner.nextDouble();

        // Calcular o desconto de 5%
        double desconto = preco * 0.05;
        double precoFinal = preco - desconto;

        // Exibir o preço promocional
        System.out.println("O preço com 5% de desconto é: R$" + String.format("%.2f", precoFinal));

        scanner.close();
    }
}
